#!/bin/bash

args=$@

sudo yum install -y $args


