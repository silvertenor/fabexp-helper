# fabproj-manager
A CLI to help create new fabric project templates in an effort to standardize experiment structure.

## Usage
`fabproj -n [--name] <fabric project name> -c [--command] new`
- Replace <fabric project name> with a desired name
- `new` is the only supported command for now.
Once you run the above command, you should see a new set of folders that serve as a template
for your fabric project.